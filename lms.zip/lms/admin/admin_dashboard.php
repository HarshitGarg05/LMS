<?php
	require("functions.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Library Management System - Dashboard</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<style>
		:root {
			--primary-color: #2c3e50;
			--secondary-color: #3498db;
			--accent-color: #e74c3c;
			--light-bg: #ecf0f1;
		}
		
		html {
			height: 100%;
		}
		
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			background-color: #f8f9fa;
			min-height: 100vh;
			display: flex;
			flex-direction: column;
		}
		
		.content-wrapper {
			flex: 1 0 auto;
		}
		
		footer {
			flex-shrink: 0;
			margin-top: auto;
		}
		
		.navbar-brand {
			font-weight: 700;
			font-size: 1.5rem;
		}
		
		.main-header {
			background-color: var(--primary-color);
			color: white;
			padding: 1rem 0;
		}
		
		.user-info {
			padding: 0.5rem 1rem;
			border-radius: 5px;
			background-color: rgba(255, 255, 255, 0.1);
		}
		
		.stats-card {
			border-radius: 10px;
			border: none;
			box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
			transition: transform 0.3s ease;
		}
		
		.stats-card:hover {
			transform: translateY(-5px);
		}
		
		.card-header {
			font-weight: 600;
			border-bottom: 2px solid var(--secondary-color);
		}
		
		.btn-custom {
			border-radius: 5px;
			padding: 0.5rem 1.5rem;
			font-weight: 500;
		}
		
		.menu-icon {
			margin-right: 0.5rem;
		}
		
		.dropdown-menu {
			border-radius: 5px;
			box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
		}
		
		.secondary-nav {
			background-color: var(--light-bg);
			box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
		}
		
		.announcement {
			background-color: var(--light-bg);
			padding: 1rem;
			border-radius: 5px;
			margin-bottom: 1.5rem;
			font-weight: 500;
		}
	</style>
</head>
<body>
	<div class="content-wrapper">
		<!-- Main navbar -->
		<nav class="navbar navbar-expand-lg navbar-dark main-header">
			<div class="container">
				<a class="navbar-brand" href="admin_dashboard.php">
					<i class="fas fa-book-reader me-2"></i>Library Management System
				</a>
				
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
					<span class="navbar-toggler-icon"></span>
				</button>
				
				<div class="collapse navbar-collapse" id="navbarNav">
					<ul class="navbar-nav ms-auto">
						<li class="nav-item me-3">
							<div class="user-info">
								<i class="fas fa-user-circle me-1"></i>
								<span><?php echo $_SESSION['name']; ?></span>
							</div>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
								<i class="fas fa-user-cog menu-icon"></i>My Profile
							</a>
							<ul class="dropdown-menu dropdown-menu-end">
								<li><a class="dropdown-item" href="view_profile.php"><i class="fas fa-id-card menu-icon"></i>View Profile</a></li>
								<li><a class="dropdown-item" href="edit_profile.php"><i class="fas fa-user-edit menu-icon"></i>Edit Profile</a></li>
								<li><a class="dropdown-item" href="change_password.php"><i class="fas fa-key menu-icon"></i>Change Password</a></li>
							</ul>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="../logout.php">
								<i class="fas fa-sign-out-alt menu-icon"></i>Logout
							</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		
		<!-- Secondary navigation -->
		<nav class="navbar navbar-expand-lg navbar-light secondary-nav">
			<div class="container">
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#secondaryNav">
					<span class="navbar-toggler-icon"></span>
				</button>
				
				<div class="collapse navbar-collapse" id="secondaryNav">
					<ul class="navbar-nav mx-auto">
						<li class="nav-item">
							<a class="nav-link active" href="admin_dashboard.php">
								<i class="fas fa-tachometer-alt menu-icon"></i>Dashboard
							</a>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
								<i class="fas fa-book menu-icon"></i>Books
							</a>
							<ul class="dropdown-menu">
								<li><a class="dropdown-item" href="add_book.php"><i class="fas fa-plus-circle menu-icon"></i>Add New Book</a></li>
								<li><a class="dropdown-item" href="manage_book.php"><i class="fas fa-cogs menu-icon"></i>Manage Books</a></li>
							</ul>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
								<i class="fas fa-tags menu-icon"></i>Categories
							</a>
							<ul class="dropdown-menu">
								<li><a class="dropdown-item" href="add_cat.php"><i class="fas fa-plus-circle menu-icon"></i>Add New Category</a></li>
								<li><a class="dropdown-item" href="manage_cat.php"><i class="fas fa-cogs menu-icon"></i>Manage Categories</a></li>
							</ul>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
								<i class="fas fa-user-edit menu-icon"></i>Authors
							</a>
							<ul class="dropdown-menu">
								<li><a class="dropdown-item" href="add_author.php"><i class="fas fa-plus-circle menu-icon"></i>Add New Author</a></li>
								<li><a class="dropdown-item" href="manage_author.php"><i class="fas fa-cogs menu-icon"></i>Manage Authors</a></li>
							</ul>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="issue_book.php">
								<i class="fas fa-arrow-circle-right menu-icon"></i>Issue Book
							</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		
		<!-- Main content -->
		<div class="container mt-4">
			<div class="announcement">
				<i class="fas fa-bullhorn me-2"></i>
				Library opens at 8:00 AM and closes at 8:00 PM
			</div>
			
			<div class="row g-4">
				<div class="col-md-6 col-lg-4">
					<div class="card stats-card h-100">
						<div class="card-header bg-white">
							<i class="fas fa-users me-2 text-primary"></i>Registered Users
						</div>
						<div class="card-body">
							<h3 class="card-title mb-3"><?php echo get_user_count(); ?></h3>
							<p class="card-text text-muted">Total registered users in the system</p>
							<a class="btn btn-primary btn-custom" href="Regusers.php" target="_blank">
								<i class="fas fa-eye me-1"></i>View Users
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 col-lg-4">
					<div class="card stats-card h-100">
						<div class="card-header bg-white">
							<i class="fas fa-book me-2 text-success"></i>Books Collection
						</div>
						<div class="card-body">
							<h3 class="card-title mb-3"><?php echo get_book_count(); ?></h3>
							<p class="card-text text-muted">Total books available in the library</p>
							<a class="btn btn-success btn-custom" href="Regbooks.php" target="_blank">
								<i class="fas fa-eye me-1"></i>View Books
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 col-lg-4">
					<div class="card stats-card h-100">
						<div class="card-header bg-white">
							<i class="fas fa-tags me-2 text-warning"></i>Book Categories
						</div>
						<div class="card-body">
							<h3 class="card-title mb-3"><?php echo get_category_count(); ?></h3>
							<p class="card-text text-muted">Total book categories in the system</p>
							<a class="btn btn-warning btn-custom" href="Regcat.php" target="_blank">
								<i class="fas fa-eye me-1"></i>View Categories
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 col-lg-4">
					<div class="card stats-card h-100">
						<div class="card-header bg-white">
							<i class="fas fa-user-edit me-2 text-info"></i>Authors
						</div>
						<div class="card-body">
							<h3 class="card-title mb-3"><?php echo get_author_count(); ?></h3>
							<p class="card-text text-muted">Total authors in the database</p>
							<a class="btn btn-info text-white btn-custom" href="Regauthor.php" target="_blank">
								<i class="fas fa-eye me-1"></i>View Authors
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 col-lg-4">
					<div class="card stats-card h-100">
						<div class="card-header bg-white">
							<i class="fas fa-clipboard-list me-2 text-danger"></i>Issued Books
						</div>
						<div class="card-body">
							<h3 class="card-title mb-3"><?php echo get_issue_book_count(); ?></h3>
							<p class="card-text text-muted">Total books currently issued</p>
							<a class="btn btn-danger btn-custom" href="view_issued_book.php" target="_blank">
								<i class="fas fa-eye me-1"></i>View Issued Books
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<!-- Footer -->
	<footer class="bg-dark text-white text-center py-3 mt-5">
		<div class="container">
			<p class="mb-0">&copy; <?php echo date('Y'); ?> Library Management System. All rights reserved.</p>
		</div>
	</footer>
	
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>