<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Library Management System | User Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f5f5f5;
            --card-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .content-wrapper {
            flex: 1 0 auto;
        }
        
        footer {
            flex-shrink: 0;
            margin-top: auto;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        
        .main-header {
            background-color: var(--primary-color);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .announcement {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem;
            border-radius: 5px;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--accent-color);
            box-shadow: var(--card-shadow);
        }
        
        .main-content {
            background-color: white;
            padding: 2.5rem;
            border-radius: 10px;
            box-shadow: var(--card-shadow);
        }
        
        .side-bar {
            background-color: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: var(--card-shadow);
            height: 100%;
        }
        
        .info-heading {
            color: var(--primary-color);
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 0.5rem;
            margin-bottom: 1rem;
            font-weight: 600;
        }
        
        .info-list {
            list-style-type: none;
            padding-left: 0;
            margin-bottom: 1.5rem;
        }
        
        .info-list li {
            padding: 0.5rem 0;
            border-bottom: 1px solid #eee;
        }
        
        .info-list li:before {
            content: "→";
            color: var(--secondary-color);
            margin-right: 0.5rem;
        }
        
        .form-title {
            color: var(--primary-color);
            position: relative;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }
        
        .form-title:after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background-color: var(--secondary-color);
        }
        
        .form-control {
            border-radius: 5px;
            padding: 0.75rem;
            border: 1px solid #ddd;
            margin-bottom: 1rem;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-login {
            background-color: var(--secondary-color);
            border: none;
            padding: 0.75rem 2rem;
            font-weight: 600;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .btn-login:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .alert-message {
            padding: 0.75rem;
            border-radius: 5px;
            margin-top: 1rem;
        }
        
        .icon-feature {
            margin-right: 0.5rem;
            color: var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .side-bar {
                margin-bottom: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
        <!-- Main navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark main-header">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <i class="fas fa-book-reader me-2"></i>Library Management System
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="admin/index.php">
                                <i class="fas fa-user-shield me-1"></i>Admin Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signup.php">
                                <i class="fas fa-user-plus me-1"></i>Register
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-sign-in-alt me-1"></i>User Login
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <div class="container mt-4">
            <div class="announcement">
                <i class="fas fa-bullhorn me-2"></i>
                <strong>Library Hours:</strong> Open daily from 8:00 AM to 8:00 PM (Closed on Sundays)
            </div>
            
            <div class="row">
                <!-- Order switched for mobile: form first, then info -->
                <div class="col-lg-8 order-lg-2 mb-4">
                    <div class="main-content">
                        <h3 class="form-title text-center">User Login</h3>
                        <form action="" method="post">
                            <div class="mb-3">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope icon-feature"></i>Email Address
                                </label>
                                <input type="email" name="email" class="form-control" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock icon-feature"></i>Password
                                </label>
                                <input type="password" name="password" class="form-control" id="password" required>
                            </div>
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" name="login" class="btn btn-primary btn-login">
                                    <i class="fas fa-sign-in-alt me-2"></i>Login
                                </button>
                            </div>
                        </form>
                        
                        <?php
                        if(isset($_POST['login'])){
                            $connection = mysqli_connect("localhost","root","");
                            $db = mysqli_select_db($connection,"lms");
                            
                            // Sanitize input to prevent SQL injection
                            $email = mysqli_real_escape_string($connection, $_POST['email']);
                            $password = $_POST['password']; // Will be hashed in real implementation
                            
                            $query = "SELECT * FROM users WHERE email = '$email'";
                            $query_run = mysqli_query($connection, $query);
                            
                            if(mysqli_num_rows($query_run) > 0) {
                                $row = mysqli_fetch_assoc($query_run);
                                
                                // In a real implementation, use password_verify() instead of direct comparison
                                if($row['password'] == $password){
                                    $_SESSION['name'] = $row['name'];
                                    $_SESSION['email'] = $row['email'];
                                    
                                    // Redirect to dashboard
                                    header("Location: user_dashboard.php");
                                    exit;
                                } else {
                                    echo '<div class="alert alert-danger alert-message text-center mt-3">
                                            <i class="fas fa-exclamation-circle me-2"></i>Incorrect password! Please try again.
                                          </div>';
                                }
                            } else {
                                echo '<div class="alert alert-danger alert-message text-center mt-3">
                                        <i class="fas fa-exclamation-circle me-2"></i>Email not found! Please check your email or register.
                                      </div>';
                            }
                        }
                        ?>
                    </div>
                </div>
                
                <div class="col-lg-4 order-lg-1">
                    <div class="side-bar">
                        <h5 class="info-heading">
                            <i class="fas fa-clock me-2"></i>Library Hours
                        </h5>
                        <ul class="info-list">
                            <li>Opening: 8:00 AM</li>
                            <li>Closing: 8:00 PM</li>
                            <li>Sunday: Closed</li>
                        </ul>
                        
                        <h5 class="info-heading">
                            <i class="fas fa-laptop-house me-2"></i>Our Facilities
                        </h5>
                        <ul class="info-list">
                            <li><i class="fas fa-wifi me-2"></i>Free Wi-Fi</li>
                            <li><i class="fas fa-chair me-2"></i>Comfortable Furniture</li>
                            <li><i class="fas fa-newspaper me-2"></i>Latest Newspapers</li>
                            <li><i class="fas fa-users me-2"></i>Discussion Rooms</li>
                            <li><i class="fas fa-tint me-2"></i>Filtered Water</li>
                            <li><i class="fas fa-leaf me-2"></i>Peaceful Environment</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3 mt-5">
        <div class="container">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> Library Management System. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>